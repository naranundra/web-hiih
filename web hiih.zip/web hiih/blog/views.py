from django.shortcuts import render
from django.http import HttpResponse
from .models import Category, Post


def index(request):
    categories = Category.objects.all().order_by('name')
    context = {
        'categories' : categories
    }
    return render(request, 'index.html', context)

def post(request):    
    categories = Category.objects.all().order_by('name')
    post_list= Post.objects.all()
    context = {
        'categories' : categories,
        'posts' : post_list
    }
    return render(request, 'post.html', context)

